How to import mmd_bot's library is as follows:

<< from mmd_bot import robot >>

An example:

from mmd_bot import Client

bot = Client("Your Auth Account")